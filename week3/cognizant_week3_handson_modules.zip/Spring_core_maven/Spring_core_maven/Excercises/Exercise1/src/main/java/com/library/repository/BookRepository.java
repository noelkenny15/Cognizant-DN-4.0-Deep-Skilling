package com.library.repository;

public class BookRepository {
    public void saveBook() {
        System.out.println("Book saved to the database.");
    }
}
